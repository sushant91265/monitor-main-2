package com.tsystems.fsl.dcs.service.impl;

import com.tsystems.fsl.dcs.configuration.quartz.JobScheduleCreator;
import com.tsystems.fsl.dcs.dto.CreateJobDto;
import com.tsystems.fsl.dcs.dto.UpdateJobDto;
import com.tsystems.fsl.dcs.exception.ResourceAlreadyExistException;
import com.tsystems.fsl.dcs.exception.ResourceNotFoundException;
import com.tsystems.fsl.dcs.mapper.JobSchedulerMapper;
import com.tsystems.fsl.dcs.model.Message;
import com.tsystems.fsl.dcs.model.SchedulerJobInfo;
import com.tsystems.fsl.dcs.quartz.ConsumerCronJob;
import com.tsystems.fsl.dcs.repository.SchedulerRepository;
import com.tsystems.fsl.dcs.service.SchedulerJobService;
import lombok.extern.slf4j.Slf4j;
import org.quartz.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.scheduling.quartz.QuartzJobBean;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import static com.tsystems.fsl.dcs.model.Message.ERROR;
import static com.tsystems.fsl.dcs.model.Message.INFO;
import static com.tsystems.fsl.dcs.utils.enums.JobStatus.*;

@Transactional
@Service
@Slf4j
public class SchedulerJobServiceImpl implements SchedulerJobService {

    @Autowired
    private Scheduler scheduler;

    @Autowired
    private SchedulerFactoryBean schedulerFactoryBean;

    @Autowired
    private SchedulerRepository schedulerRepository;

    @Autowired
    private ApplicationContext context;

    @Autowired
    private JobScheduleCreator scheduleCreator;


    public Message save(CreateJobDto jobDet)  {
        var message = Message.success("Job saved successfully.");

        try {
            Optional<SchedulerJobInfo> schedulerJobInfo=schedulerRepository.findByJobName(jobDet.getJobName());
            if(schedulerJobInfo.isPresent()){
                log.error("Job already exist with job name "+jobDet.getJobName());
                throw new ResourceAlreadyExistException(String.format("Job already exist with job name: %s",jobDet.getJobName()));
            }

            var jobInfo = JobSchedulerMapper.dtoToEntity(jobDet,new SchedulerJobInfo());
            jobInfo.setJobClass(ConsumerCronJob.class.getName());
            var factoryBeanScheduler = schedulerFactoryBean.getScheduler();
            var jobDetail = JobBuilder
                    .newJob((Class<? extends QuartzJobBean>) Class.forName(jobInfo.getJobClass()))
                    .withIdentity(jobInfo.getJobName(), jobInfo.getJobGroup()).build();
            if (!factoryBeanScheduler.checkExists(jobDetail.getKey())) {

                jobDetail = scheduleCreator.createJob(
                        (Class<? extends QuartzJobBean>) Class.forName(jobInfo.getJobClass()), false, context,
                        jobInfo.getJobName(), jobInfo.getJobGroup());
                jobDetail.getJobDataMap().put("companyCodeId",jobInfo.getCompanyCodeId());
                jobDetail.getJobDataMap().put("interfaceId",jobInfo.getInterfaceId());
                Trigger trigger = scheduleCreator.createCronTrigger(
                        jobInfo.getJobName(),
                        new Date(),
                        jobInfo.getCronExpression(),
                        SimpleTrigger.MISFIRE_INSTRUCTION_FIRE_NOW);
                factoryBeanScheduler.scheduleJob(jobDetail, trigger);
                jobInfo.setJobStatus(SCHEDULED.getJobStatus());
                schedulerRepository.save(jobInfo);
                log.info(">>>>> jobName = [{}] scheduled.",jobInfo.getJobName());
            } else {//needed??
                message.setMsg("Job already exist with "+jobInfo.getJobName(), INFO);
                log.info("Job already exist with "+jobInfo.getJobName());
                return message;
            }
        }catch (SchedulerException e) {
            message.setMsg("fail to save record.",ERROR);
            log.error("fail to save record. ex:", e);
        }catch (ClassNotFoundException e) {
            message.setMsg("fail to save record.",ERROR);
            log.error("fail to save record. ex:", e);
        }

        return message;
    }

    public Message update(UpdateJobDto jobDet,Integer jobId)  {
        var message = Message.success("Job updated successfully.");
        try{
            SchedulerJobInfo schedulerJobInfo=schedulerRepository.findByJobId(jobId).orElseThrow(
                    ()->  new ResourceNotFoundException(String.format("Job detail not found with job id: %d",jobId)
            ));

            var jobInfo = JobSchedulerMapper.dtoToEntity(jobDet,schedulerJobInfo);

            jobInfo.setJobClass(ConsumerCronJob.class.getName());
            Trigger  newTrigger = scheduleCreator.createCronTrigger(
                    jobInfo.getJobName(),
                    new Date(),
                    jobInfo.getCronExpression(),
                    SimpleTrigger.MISFIRE_INSTRUCTION_FIRE_NOW);
            schedulerFactoryBean.getScheduler().rescheduleJob(TriggerKey.triggerKey(jobInfo.getJobName()), newTrigger);
            jobInfo.setJobStatus(EDIT_AND_SCHEDULED.getJobStatus());
            schedulerRepository.update(jobInfo);
            log.info(">>>>> jobName = [{}] updated and scheduled.",jobInfo.getJobName());
        } catch (SchedulerException e) {
            message.setMsg("fail to update record.",ERROR);
            log.error("fail to update record. ex:", e);
        }
       return message;
    }


    public Message pauseRunningJob(Integer jobId)  {
        var message = Message.success("Job paused successfully.");
        try {
            SchedulerJobInfo jobInfo = schedulerRepository.findByJobId(jobId).orElseThrow(
                    ()->  new ResourceNotFoundException(String.format("Job detail not found with job id: %d",jobId))
            );

            if(PAUSED.getJobStatus().equals(jobInfo.getJobStatus())){
                message.setMsg("Job is already paused. ", ERROR);
                log.info("Job already running with job id "+jobId);
            }else{
                jobInfo.setJobStatus(PAUSED.getJobStatus());
                schedulerRepository.update(jobInfo);
                schedulerFactoryBean.getScheduler().pauseJob(new JobKey(jobInfo.getJobName(), jobInfo.getJobGroup()));
                log.info(">>>>> jobName = [{}] paused.",jobInfo.getJobName());
            }

        }catch (SchedulerException e){
            message.setMsg("fail to pause job.",ERROR);
            log.error("fail to pause job. ex:", e);
        }

        return message;
    }

    public Message resumeRunningJob(Integer jobId)  {
            var message = Message.success("Job resumed successfully.");
        try{
            SchedulerJobInfo jobInfo = schedulerRepository.findByJobId(jobId).orElseThrow(
                    ()->  new ResourceNotFoundException(String.format("Job detail not found with job id: %d",jobId))
            );

                if(PAUSED.getJobStatus().equals(jobInfo.getJobStatus())){
                    jobInfo.setJobStatus(RESUMED.getJobStatus());
                    schedulerRepository.update(jobInfo);
                    schedulerFactoryBean.getScheduler().resumeJob(new JobKey(jobInfo.getJobName(), jobInfo.getJobGroup()));
                    log.info(">>>>> jobName = [{}] resumed.",jobInfo.getJobName());
                }else{
                    message.setMsg("Job already running.", INFO);
                    log.info("Job already running with job id "+jobId);
                }

        }catch (SchedulerException e){
                message.setMsg("fail to resume job.",ERROR);
                log.error("fail to resume job. ex:", e);
        }

            return message;
    }

    public Message deleteRunningJob(Integer jobId)  {
        var message = Message.success("Job deleted successfully.");
        try {
            clearAllMissMatchJobs(schedulerRepository.findAllMissMatchJobs());
            SchedulerJobInfo jobInfo = schedulerRepository.findByJobId(jobId).orElseThrow(
                    ()->  new ResourceNotFoundException(String.format("Job detail not found with job id: %d",jobId))
            );

            schedulerRepository.delete(jobInfo);
            schedulerFactoryBean.getScheduler().deleteJob(new JobKey(jobInfo.getJobName(), jobInfo.getJobGroup()));

        } catch (SchedulerException e) {
            message.setMsg("fail to delete job.",ERROR);
            log.error("fail to delete job ex:", e);
        }
        log.info(">>>>> jobName = [" + jobId + "]" + " deleted.");
        return message;
    }

    public List<SchedulerJobInfo> getAllJobList() {
        return schedulerRepository.findAll()
                                  .orElseThrow(
                                        () -> new ResourceNotFoundException("No job present!")
                                );
    }

    private void clearAllMissMatchJobs(List<SchedulerJobInfo> schedulerJobInfos){

            schedulerJobInfos.stream().forEach(  jobInfo -> {
                    try {
                        schedulerFactoryBean.getScheduler().deleteJob(new JobKey(jobInfo.getJobName(), jobInfo.getJobGroup()));
                    } catch (SchedulerException e) {
                        log.error("fail to resume job. ex:", e);
                    }
            });

    }
}
